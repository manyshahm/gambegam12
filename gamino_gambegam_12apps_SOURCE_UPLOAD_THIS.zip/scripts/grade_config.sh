#!/usr/bin/env bash
set -euo pipefail

grade="${1:?grade is required}"

case "$grade" in
  1)
    grade_word="اول"
    ADIVERY_APP_ID="e740a577-9f34-4c72-aefd-a90106af1b45"
    ADIVERY_BANNER_ID="11905f16-09f9-41c8-a50b-47a62037f62b"
    ;;
  2)
    grade_word="دوم"
    ADIVERY_APP_ID="b9214dec-a397-44b7-a5a2-79a5540f0aa7"
    ADIVERY_BANNER_ID="0d0f27c5-093d-41f3-9dd7-452fe51ff2f2"
    ;;
  3)
    grade_word="سوم"
    ADIVERY_APP_ID="68c113b9-e477-461c-a25f-77fcfede1500"
    ADIVERY_BANNER_ID="41f0dfe8-e397-4231-af83-1c899e9266c5"
    ;;
  4)
    grade_word="چهارم"
    ADIVERY_APP_ID="686ac3c1-97f3-4825-9228-81198961155e"
    ADIVERY_BANNER_ID="7e9294ed-d8f5-4457-aa54-02027ba42324"
    ;;
  5)
    grade_word="پنجم"
    ADIVERY_APP_ID="d40ffb65-f8c6-4811-8da4-10f20183346f"
    ADIVERY_BANNER_ID="d67761d3-27dd-4d0f-b778-0d3e020d25da"
    ;;
  6)
    grade_word="ششم"
    ADIVERY_APP_ID="787fecd4-99a7-442a-b453-cb8d0627aef5"
    ADIVERY_BANNER_ID="e83f9b7a-0e78-4a0f-a8b1-4f257c6d9e4b"
    ;;
  7)
    grade_word="هفتم"
    ADIVERY_APP_ID="d318a9ec-cb3d-4282-b3e5-8327bc1d237f"
    ADIVERY_BANNER_ID="839813ff-c986-4bbc-a85a-beaa30ce57de"
    ;;
  8)
    grade_word="هشتم"
    ADIVERY_APP_ID="2fdf4245-886e-49eb-8d25-4c5281b45e00"
    ADIVERY_BANNER_ID="cb5149bb-fcd4-4a72-b4f1-317898892f9e"
    ;;
  9)
    grade_word="نهم"
    ADIVERY_APP_ID="e2858398-83b7-47b1-8e71-f0b9dd417297"
    ADIVERY_BANNER_ID="51ffe96c-d623-4f5f-ae24-9eb7de2cca44"
    ;;
  10)
    grade_word="دهم"
    ADIVERY_APP_ID="2a96ec89-b7c9-46c8-821c-ab0f11db5411"
    ADIVERY_BANNER_ID="f0ff5850-48c7-4dc0-bd63-798f06fa8bf3"
    ;;
  11)
    grade_word="یازدهم"
    ADIVERY_APP_ID="6f8bfec4-d722-46f0-8c4d-0bd148fc7763"
    ADIVERY_BANNER_ID="04222a26-c19a-426f-bf94-8496237e1ced"
    ;;
  12)
    grade_word="دوازدهم"
    ADIVERY_APP_ID="83006eea-307c-42ec-aa84-ad99eb3026cf"
    ADIVERY_BANNER_ID="0e5b5e4f-5fdb-4136-944d-af9f93ffee78"
    ;;
  *)
    echo "grade must be 1..12" >&2
    exit 2
    ;;
esac

printf -v grade_padded '%02d' "$grade"
APP_LABEL="گام به گام پایه ${grade_word}"
APP_PACKAGE="ir.miplus.gambegam${grade_padded}"
APP_SLUG="grade${grade_padded}"

printf 'APP_LABEL=%s\n' "$APP_LABEL"
printf 'APP_PACKAGE=%s\n' "$APP_PACKAGE"
printf 'APP_SLUG=%s\n' "$APP_SLUG"
printf 'TARGET_GRADE=%s\n' "$grade"
printf 'ADIVERY_APP_ID=%s\n' "$ADIVERY_APP_ID"
printf 'ADIVERY_BANNER_ID=%s\n' "$ADIVERY_BANNER_ID"
