# گام‌به‌گام ۱۲ پایه — سورس مشترک

این پروژه یک Codebase مشترک Flutter برای ۱۲ اپ مستقل پایه اول تا دوازدهم است.

## Build
Workflow جداگانه `build-12-grades.yml` یک ZIP سورس معتبر را از Repository پیدا می‌کند و همان سورس را برای پایه‌های ۱ تا ۱۲ Build می‌کند.

- نام ZIP سورس آزاد است.
- آیکن‌های هر ۱۲ پایه داخل خود ZIP سورس Embed شده‌اند؛ هیچ ZIP آیکن جداگانه‌ای لازم نیست.
- Package Nameها از `ir.miplus.gambegam01` تا `ir.miplus.gambegam12` هستند.
- برای هر پایه APK + AAB مستقل ساخته می‌شود.
- پایه‌های ۱۰، ۱۱ و ۱۲ انتخاب رشته ریاضی / تجربی / انسانی دارند.
- App ID و Banner Placement ID ادیوری برای هر پایه مستقل است.
- فقط Banner Adivery استفاده می‌شود؛ Interstitial و Rewarded استفاده نمی‌شوند.
- PDF به‌صورت اسکرول عمودی بدون page snap نمایش داده می‌شود.

## GitHub
در Repository فقط این موارد کافی است:
1. فایل ZIP سورس
2. فایل `.github/workflows/build-12-grades.yml`

Workflow سورس ZIP را از Marker داخلی `.gambegam12-source` تشخیص می‌دهد.
