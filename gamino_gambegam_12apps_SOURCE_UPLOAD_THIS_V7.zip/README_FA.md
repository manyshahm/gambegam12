# گام‌به‌گام ۱۲ پایه — سورس مشترک

این پروژه یک Codebase مشترک Flutter برای ۱۲ اپ مستقل پایه اول تا دوازدهم است.

## رفتار فعلی
- Package Nameها: `ir.miplus.gambegam01` تا `ir.miplus.gambegam12`.
- پایه‌های ۱۰، ۱۱ و ۱۲ انتخاب رشته ریاضی / تجربی / انسانی دارند.
- محتوا فقط از `guest.books` بک‌اند فعلی گامینو دریافت می‌شود.
- محتوا Offline-first / Stale-While-Revalidate است: کش قبلی فوراً نمایش داده می‌شود و Refresh شبکه در پس‌زمینه انجام می‌شود.
- PDF دانلودشده در کش داخلی باقی می‌ماند و اسکرول عمودی بدون Page Snap دارد.
- Splash هر پایه ۲.۵ ثانیه است و آیکن همان پایه + نام پایه + Loading را نشان می‌دهد.
- صفحه اصلی کارت بنفش قدیمی ندارد؛ جای آن یک اسلایدر ۲ بنری Adivery با سایز `LARGE_BANNER` (320×100) و گردش ۳۰ ثانیه‌ای قرار دارد.
- صفحه PDF در پایین یک اسلایدر ۲ بنری 320×100 با گردش ۴۰ ثانیه‌ای دارد.
- هر دو اسلایدر Swipe دستی و Loop ۱↔۲ دارند.
- Interstitial فقط هنگام لمس یک درس و قبل از ورود به PDF همان درس نمایش داده می‌شود؛ در صورت No-fill/خطا/لودنشدن، درس بدون مانع باز می‌شود.
- Banner و Interstitial هر دو از همان وضعیت `adiveryInterstitialEnabled` که پنل فعلی گامینو در `guest.books` می‌دهد تبعیت می‌کنند.
- App ID، Banner Placement و Interstitial Placement برای هر پایه مستقل است.
- دکمه «درباره ما» در AppBar صفحه اصلی وجود دارد.

## Build
فایل Workflow جداگانه `build-12-grades.yml` یک ZIP سورس معتبر را با هر نامی از Repository پیدا می‌کند و برای پایه‌های ۱ تا ۱۲ Build می‌کند.

- آیکن‌های هر ۱۲ پایه داخل ZIP سورس Embed هستند.
- Workflow قبل از Build آیکن پایه را هم برای Launcher و هم `assets/app_icon.png` اعمال می‌کند.
- برای هر پایه APK + AAB مستقل ساخته می‌شود.
- نسخه ثابت: `1.0.0+1`.

## GitHub
در Repository فقط این موارد کافی است:
1. فایل ZIP سورس (بدون Extract)
2. فایل `.github/workflows/build-12-grades.yml`

Workflow سورس را از Marker داخلی `.gambegam12-source` تشخیص می‌دهد.
