package ir.miplus.gambegam

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
