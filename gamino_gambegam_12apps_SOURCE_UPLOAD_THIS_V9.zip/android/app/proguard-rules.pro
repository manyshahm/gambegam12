# Release shrinking is disabled, but keep Adivery classes safe if shrinking is enabled later.
-keep class com.adivery.** { *; }
-dontwarn com.adivery.**
