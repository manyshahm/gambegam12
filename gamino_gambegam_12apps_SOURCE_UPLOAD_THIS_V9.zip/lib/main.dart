import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:adivery/adivery.dart';
import 'package:adivery/adivery_ads.dart';
import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String kApiBaseUrl = String.fromEnvironment(
  'GAMINO_API_URL',
  defaultValue: 'https://gaminoapp.ir/gamino/api',
);
const int kTargetGrade = int.fromEnvironment('TARGET_GRADE', defaultValue: 1);
const String kBuildAppName = String.fromEnvironment('APP_NAME', defaultValue: 'گام به گام');
const String kAdiveryAppId = String.fromEnvironment('ADIVERY_APP_ID', defaultValue: '');
const String kAdiveryBannerPlacementId = String.fromEnvironment('ADIVERY_BANNER_ID', defaultValue: '');
const String kAdiveryInterstitialPlacementId = String.fromEnvironment('ADIVERY_INTERSTITIAL_ID', defaultValue: '');
const List<String> kSeniorTracks = ['ریاضی', 'تجربی', 'انسانی'];

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GradeStepByStepApp());
}

class GradeStepByStepApp extends StatelessWidget {
  const GradeStepByStepApp({super.key});

  @override
  Widget build(BuildContext context) {
    final grade = kTargetGrade.clamp(1, 12).toInt();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: kBuildAppName,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6C4EE3),
          primary: const Color(0xFF6C4EE3),
          secondary: const Color(0xFF25A56A),
          surface: const Color(0xFFF8F8FC),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F6FA),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF25233A),
          elevation: 0,
          scrolledUnderElevation: 1,
          titleTextStyle: TextStyle(
            color: Color(0xFF25233A),
            fontSize: 19,
            fontWeight: FontWeight.w900,
          ),
        ),
        cardTheme: CardTheme(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE8E8F0)),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF25A56A),
            foregroundColor: Colors.white,
            minimumSize: const Size(44, 46),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            textStyle: const TextStyle(fontWeight: FontWeight.w900),
          ),
        ),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: SplashGate(grade: grade),
    );
  }
}

String gradeLabel(int grade) {
  const labels = <int, String>{
    1: 'اول',
    2: 'دوم',
    3: 'سوم',
    4: 'چهارم',
    5: 'پنجم',
    6: 'ششم',
    7: 'هفتم',
    8: 'هشتم',
    9: 'نهم',
    10: 'دهم',
    11: 'یازدهم',
    12: 'دوازدهم',
  };
  return labels[grade] ?? grade.toString();
}

String normalizeTrack(int grade, String track) {
  if (grade < 10) return '';
  return kSeniorTracks.contains(track) ? track : kSeniorTracks.first;
}

String gradePathText(int grade, String track) {
  final base = 'پایه ${gradeLabel(grade)}';
  final normalized = normalizeTrack(grade, track);
  return normalized.isEmpty ? base : '$base • $normalized';
}


class SplashGate extends StatefulWidget {
  const SplashGate({super.key, required this.grade});

  final int grade;

  @override
  State<SplashGate> createState() => _SplashGateState();
}

class _SplashGateState extends State<SplashGate> {
  Timer? _timer;

  @override
  void initState() {
    super.initState();
    AdiveryCoordinator.initialize();
    _timer = Timer(const Duration(milliseconds: 2500), () {
      if (!mounted) return;
      Navigator.of(context).pushReplacement(
        MaterialPageRoute(builder: (_) => StepByStepHome(grade: widget.grade)),
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Center(
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 28),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.circular(28),
                  child: Image.asset(
                    'assets/app_icon.png',
                    width: 112,
                    height: 112,
                    fit: BoxFit.cover,
                  ),
                ),
                const SizedBox(height: 22),
                Text(
                  'گام به گام ${gradeLabel(widget.grade)}',
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w900,
                    color: Color(0xFF25233A),
                  ),
                ),
                const SizedBox(height: 30),
                const SizedBox(
                  width: 34,
                  height: 34,
                  child: CircularProgressIndicator(strokeWidth: 3.2),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class AdiveryCoordinator {
  static bool _initialized = false;
  static bool _enabled = false;
  static bool _interstitialPrepared = false;
  static Completer<void>? _pendingInterstitial;

  static bool get enabled => _enabled;

  static void initialize() {
    if (_initialized || kAdiveryAppId.trim().isEmpty) return;
    AdiveryPlugin.initialize(kAdiveryAppId);
    AdiveryPlugin.setLoggingEnabled(false);
    AdiveryPlugin.addListener(
      onInterstitialClosed: _onInterstitialClosed,
      onError: _onError,
    );
    _initialized = true;
  }

  static void configure(bool enabled) {
    initialize();
    _enabled = enabled;
    if (!_enabled || _interstitialPrepared || kAdiveryInterstitialPlacementId.trim().isEmpty) return;
    AdiveryPlugin.prepareInterstitialAd(kAdiveryInterstitialPlacementId);
    _interstitialPrepared = true;
  }

  static Future<void> showInterstitialIfReady() async {
    if (!_enabled || kAdiveryInterstitialPlacementId.trim().isEmpty || !_initialized) return;
    try {
      final loaded = await AdiveryPlugin.isLoaded(kAdiveryInterstitialPlacementId)
          .timeout(const Duration(milliseconds: 1200), onTimeout: () => false);
      if (loaded != true) return;
      final completer = Completer<void>();
      _pendingInterstitial = completer;
      AdiveryPlugin.show(kAdiveryInterstitialPlacementId);
      await completer.future.timeout(
        const Duration(seconds: 90),
        onTimeout: () {},
      );
    } catch (_) {
      // Ads must never block opening educational content.
    } finally {
      _pendingInterstitial = null;
    }
  }

  static void _finishInterstitial(String placement) {
    if (placement != kAdiveryInterstitialPlacementId) return;
    final pending = _pendingInterstitial;
    if (pending != null && !pending.isCompleted) pending.complete();
  }

  static void _onInterstitialClosed(String placement) => _finishInterstitial(placement);

  static void _onError(String placement, String reason) => _finishInterstitial(placement);
}

class LearningLesson {
  const LearningLesson({
    required this.id,
    required this.title,
    required this.lessonNumber,
    required this.sortOrder,
    required this.updatedAt,
    required this.stepPdfUrl,
  });

  final String id;
  final String title;
  final int lessonNumber;
  final int sortOrder;
  final String updatedAt;
  final String stepPdfUrl;

  factory LearningLesson.fromJson(Map<String, dynamic> json) => LearningLesson(
        id: json['id']?.toString() ?? '',
        title: (json['title']?.toString() ?? '').trim().isNotEmpty ? json['title'].toString() : 'درس',
        lessonNumber: (json['lessonNumber'] as num?)?.toInt() ?? 0,
        sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
        updatedAt: json['updatedAt']?.toString() ?? '',
        stepPdfUrl: json['stepPdfUrl']?.toString() ?? '',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'lessonNumber': lessonNumber,
        'sortOrder': sortOrder,
        'updatedAt': updatedAt,
        'stepPdfUrl': stepPdfUrl,
      };
}

class LearningBook {
  const LearningBook({
    required this.id,
    required this.grade,
    required this.track,
    required this.title,
    required this.coverUrl,
    required this.pdfUrl,
    required this.sortOrder,
    required this.updatedAt,
    required this.lessons,
  });

  final String id;
  final int grade;
  final String track;
  final String title;
  final String coverUrl;
  final String pdfUrl;
  final int sortOrder;
  final String updatedAt;
  final List<LearningLesson> lessons;

  bool get hasPdf => pdfUrl.trim().isNotEmpty;

  factory LearningBook.fromJson(Map<String, dynamic> json) {
    final lessons = (json['lessons'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => LearningLesson.fromJson(Map<String, dynamic>.from(item)))
        .where((item) => item.stepPdfUrl.trim().isNotEmpty)
        .toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return LearningBook(
      id: json['id']?.toString() ?? '',
      grade: (json['grade'] as num?)?.toInt() ?? kTargetGrade,
      track: json['track']?.toString() ?? '',
      title: (json['title']?.toString() ?? '').trim().isNotEmpty ? json['title'].toString() : 'کتاب',
      coverUrl: json['coverUrl']?.toString() ?? '',
      pdfUrl: json['pdfUrl']?.toString() ?? '',
      sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
      updatedAt: json['updatedAt']?.toString() ?? '',
      lessons: lessons,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'grade': grade,
        'track': track,
        'title': title,
        'coverUrl': coverUrl,
        'pdfUrl': pdfUrl,
        'sortOrder': sortOrder,
        'updatedAt': updatedAt,
        'lessons': lessons.map((e) => e.toJson()).toList(),
      };
}

class ContentPayload {
  const ContentPayload({required this.books, required this.adiveryBannerEnabled});

  final List<LearningBook> books;
  final bool adiveryBannerEnabled;
}

class ContentApi {
  static Future<ContentPayload> loadBooks({required int grade, required String track}) async {
    final uri = Uri.parse('$kApiBaseUrl/index.php?action=guest.books');
    late http.Response response;
    try {
      response = await http
          .post(
            uri,
            headers: const {
              'Accept': 'application/json',
              'Content-Type': 'application/json; charset=utf-8',
            },
            body: jsonEncode({'grade': grade, 'track': normalizeTrack(grade, track)}),
          )
          .timeout(const Duration(seconds: 18));
    } on TimeoutException {
      throw const ContentException('پاسخ سرور طول کشید. اتصال اینترنت را بررسی کنید.');
    } on SocketException {
      throw const ContentException('اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.');
    } catch (_) {
      throw const ContentException('اتصال به سرور انجام نشد.');
    }

    Map<String, dynamic> decoded;
    try {
      final raw = jsonDecode(response.body);
      if (raw is! Map) throw const FormatException();
      decoded = Map<String, dynamic>.from(raw);
    } catch (_) {
      throw const ContentException('پاسخ معتبر از سرور دریافت نشد.');
    }

    if (response.statusCode < 200 || response.statusCode >= 300 || decoded['ok'] != true) {
      throw ContentException(decoded['error']?.toString() ?? 'دریافت محتوا از سرور ناموفق بود.');
    }

    final data = decoded['data'];
    if (data is! Map) {
      return const ContentPayload(books: [], adiveryBannerEnabled: false);
    }
    final payload = Map<String, dynamic>.from(data);
    final rows = payload['books'] as List? ?? const [];
    final books = rows
        .whereType<Map>()
        .map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item)))
        .toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return ContentPayload(
      books: books,
      // The existing Gamino admin toggle is exposed by guest.books under this
      // legacy key. In these 12 apps it controls the standard Adivery banner.
      adiveryBannerEnabled: payload['adiveryInterstitialEnabled'] == true,
    );
  }
}

class ContentException implements Exception {
  const ContentException(this.message);
  final String message;
  @override
  String toString() => message;
}

class LocalContentCache {
  static String _key(int grade, String track) => 'gambegam_books_v1_${grade}_${normalizeTrack(grade, track)}';

  static Future<void> save(int grade, String track, List<LearningBook> books) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key(grade, track), jsonEncode(books.map((e) => e.toJson()).toList()));
  }

  static Future<List<LearningBook>> read(int grade, String track) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key(grade, track));
    if (raw == null || raw.isEmpty) return const [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return const [];
      final books = decoded
          .whereType<Map>()
          .map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item)))
          .toList()
        ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
      return books;
    } catch (_) {
      return const [];
    }
  }

  static String _adsKey(int grade, String track) => 'gambegam_ads_v1_${grade}_${normalizeTrack(grade, track)}';

  static Future<void> saveAdsEnabled(int grade, String track, bool enabled) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_adsKey(grade, track), enabled);
  }

  static Future<bool> readAdsEnabled(int grade, String track) async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_adsKey(grade, track)) ?? false;
  }

  static Future<String> readTrack(int grade) async {
    if (grade < 10) return '';
    final prefs = await SharedPreferences.getInstance();
    return normalizeTrack(grade, prefs.getString('gambegam_track_v1_$grade') ?? '');
  }

  static Future<void> saveTrack(int grade, String track) async {
    if (grade < 10) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gambegam_track_v1_$grade', normalizeTrack(grade, track));
  }
}

class StepByStepHome extends StatefulWidget {
  const StepByStepHome({super.key, required this.grade});
  final int grade;

  @override
  State<StepByStepHome> createState() => _StepByStepHomeState();
}

class _StepByStepHomeState extends State<StepByStepHome> {
  List<LearningBook> _books = const [];
  String _track = '';
  bool _loading = true;
  String _error = '';
  bool _adsEnabled = false;

  @override
  void initState() {
    super.initState();
    AdiveryCoordinator.initialize();
    _initialize();
  }

  Future<void> _initialize() async {
    final storedTrack = await LocalContentCache.readTrack(widget.grade);
    final track = widget.grade < 10 ? '' : storedTrack;
    final cached = await LocalContentCache.read(widget.grade, track);
    final cachedAds = await LocalContentCache.readAdsEnabled(widget.grade, track);
    if (!mounted) return;
    setState(() {
      _track = track;
      _books = cached;
      _adsEnabled = cachedAds;
      _loading = cached.isEmpty;
      _error = '';
    });
    AdiveryCoordinator.configure(cachedAds);
    unawaited(_refreshFromNetwork(showLoadingWhenEmpty: cached.isEmpty));
  }

  Future<void> _refreshFromNetwork({bool showLoadingWhenEmpty = false}) async {
    if (showLoadingWhenEmpty && _books.isEmpty && mounted) {
      setState(() {
        _loading = true;
        _error = '';
      });
    }
    try {
      final payload = await ContentApi.loadBooks(grade: widget.grade, track: _track);
      await Future.wait([
        LocalContentCache.save(widget.grade, _track, payload.books),
        LocalContentCache.saveAdsEnabled(widget.grade, _track, payload.adiveryBannerEnabled),
      ]);
      if (!mounted) return;
      setState(() {
        _books = payload.books;
        _adsEnabled = payload.adiveryBannerEnabled;
        _loading = false;
        _error = '';
      });
      AdiveryCoordinator.configure(payload.adiveryBannerEnabled);
    } catch (error) {
      if (!mounted) return;
      // Stale-while-revalidate: when cached content exists, a failed refresh is silent.
      if (_books.isNotEmpty) {
        setState(() {
          _loading = false;
          _error = '';
        });
        return;
      }
      setState(() {
        _loading = false;
        _error = error.toString();
      });
    }
  }

  Future<void> _changeTrack(String track) async {
    final next = normalizeTrack(widget.grade, track);
    if (next == _track) return;
    await LocalContentCache.saveTrack(widget.grade, next);
    final cached = await LocalContentCache.read(widget.grade, next);
    final cachedAds = await LocalContentCache.readAdsEnabled(widget.grade, next);
    if (!mounted) return;
    setState(() {
      _track = next;
      _books = cached;
      _adsEnabled = cachedAds;
      _error = '';
      _loading = cached.isEmpty;
    });
    AdiveryCoordinator.configure(cachedAds);
    unawaited(_refreshFromNetwork(showLoadingWhenEmpty: cached.isEmpty));
  }

  void _showAbout() {
    showDialog<void>(
      context: context,
      builder: (dialogContext) => AlertDialog(
        title: const Text('درباره ما', style: TextStyle(fontWeight: FontWeight.w900)),
        content: const Text(
          'محتوای آموزشی این برنامه توسط تیم سازنده گردآوری، تدوین و برای استفاده در همین اپ آماده‌سازی شده است. '
          'هرگونه کپی‌برداری، بازنشر، استخراج یا استفاده تجاری از محتوای برنامه بدون کسب اجازه، مجاز نیست و در صورت تخلف، پیگیری قانونی انجام خواهد شد.',
          style: TextStyle(height: 1.8, fontWeight: FontWeight.w700),
        ),
        actions: [
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(),
            child: const Text('بستن'),
          ),
        ],
      ),
    );
  }

  Future<bool> _confirmExit() async {
    final shouldExit = await showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (dialogContext) => AlertDialog(
        insetPadding: const EdgeInsets.symmetric(horizontal: 54, vertical: 24),
        contentPadding: const EdgeInsets.fromLTRB(20, 18, 20, 6),
        actionsPadding: const EdgeInsets.fromLTRB(8, 0, 8, 8),
        content: const Text(
          'آیا مطمئنید که می‌خواهید خارج شوید؟',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 14, fontWeight: FontWeight.w800, height: 1.45),
        ),
        actionsAlignment: MainAxisAlignment.spaceEvenly,
        actions: [
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('خیر', style: TextStyle(fontWeight: FontWeight.w900)),
          ),
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: const Text('بله', style: TextStyle(color: Colors.red, fontWeight: FontWeight.w900)),
          ),
        ],
      ),
    );
    return shouldExit ?? false;
  }

  @override
  Widget build(BuildContext context) {
    final gradeText = gradePathText(widget.grade, _track);
    return WillPopScope(
      onWillPop: _confirmExit,
      child: Scaffold(
        appBar: AppBar(
        automaticallyImplyLeading: false,
        titleSpacing: 16,
        title: Text('گام به گام پایه ${gradeLabel(widget.grade)}'),
        actions: [
          Padding(
            padding: const EdgeInsetsDirectional.only(end: 8),
            child: TextButton.icon(
              onPressed: _showAbout,
              icon: const Icon(Icons.info_outline_rounded, size: 18),
              label: const Text('درباره ما', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 12)),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () => _refreshFromNetwork(showLoadingWhenEmpty: _books.isEmpty),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            children: [
              _AdiveryBannerCarousel(
                enabled: true,
                interval: const Duration(seconds: 30),
              ),
              if (widget.grade >= 10) ...[
                const SizedBox(height: 14),
                _TrackSelector(selected: _track, onChanged: _changeTrack),
              ],
              if (_loading) ...[
                const SizedBox(height: 14),
                const LinearProgressIndicator(minHeight: 3),
              ],
              const SizedBox(height: 18),
              Text(
                'کتاب‌های $gradeText',
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Color(0xFF25233A)),
              ),
              const SizedBox(height: 10),
              if (!_loading && _books.isEmpty)
                _EmptyState(error: _error, onRetry: () => _refreshFromNetwork(showLoadingWhenEmpty: true))
              else
                ..._books.map((book) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _BookTile(book: book, adsEnabled: _adsEnabled),
                    )),
            ],
          ),
        ),
        ),
      ),
    );
  }
}

class _TrackSelector extends StatelessWidget {
  const _TrackSelector({required this.selected, required this.onChanged});
  final String selected;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('انتخاب رشته', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: kSeniorTracks
                  .map(
                    (track) => ChoiceChip(
                      label: Text(track, style: const TextStyle(fontWeight: FontWeight.w900)),
                      selected: normalizeTrack(10, selected) == track,
                      onSelected: (_) => onChanged(track),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.error, required this.onRetry});
  final String error;
  final Future<void> Function() onRetry;

  @override
  Widget build(BuildContext context) {
    final message = error.trim().isEmpty
        ? 'هنوز محتوایی برای این پایه ثبت نشده است.'
        : error;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const Icon(Icons.cloud_off_rounded, size: 46, color: Color(0xFF6C4EE3)),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.7)),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: onRetry,
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('تلاش دوباره'),
            ),
          ],
        ),
      ),
    );
  }
}

class _BookTile extends StatelessWidget {
  const _BookTile({required this.book, required this.adsEnabled});
  final LearningBook book;
  final bool adsEnabled;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        leading: _BookCover(url: book.coverUrl),
        title: Text(book.title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            '${book.lessons.length} درس${book.hasPdf ? ' • PDF کامل' : ''}',
            style: const TextStyle(color: Color(0xFF77758A), fontWeight: FontWeight.w700),
          ),
        ),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => BookScreen(book: book, adsEnabled: adsEnabled))),
      ),
    );
  }
}

class _BookCover extends StatelessWidget {
  const _BookCover({required this.url, this.size = 56});
  final String url;
  final double size;

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      width: size,
      height: size * 1.23,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: const LinearGradient(colors: [Color(0xFF6C4EE3), Color(0xFF9B8AF4)]),
      ),
      alignment: Alignment.center,
      child: Icon(Icons.menu_book_rounded, color: Colors.white, size: size * .43),
    );
    if (url.trim().isEmpty) return placeholder;
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Image.network(
        url,
        width: size,
        height: size * 1.23,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => placeholder,
      ),
    );
  }
}

class BookScreen extends StatelessWidget {
  const BookScreen({super.key, required this.book, required this.adsEnabled});
  final LearningBook book;
  final bool adsEnabled;

  Future<void> _openPdf(
    BuildContext context, {
    required String title,
    required String url,
    required String documentId,
    bool showInterstitial = false,
  }) async {
    if (url.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لینک PDF برای این مورد ثبت نشده است.')));
      return;
    }
    if (showInterstitial && adsEnabled) {
      await AdiveryCoordinator.showInterstitialIfReady();
    }
    if (!context.mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PdfReaderScreen(title: title, pdfUrl: url, documentId: documentId, adsEnabled: adsEnabled),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(book.title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _BookCover(url: book.coverUrl, size: 84),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(book.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                          const SizedBox(height: 7),
                          Text(gradePathText(book.grade, book.track), style: const TextStyle(color: Color(0xFF77758A), fontWeight: FontWeight.w700)),
                          if (book.hasPdf) ...[
                            const SizedBox(height: 12),
                            FilledButton.icon(
                              onPressed: () => _openPdf(
                                context,
                                title: 'PDF کامل — ${book.title}',
                                url: book.pdfUrl,
                                documentId: 'book_${book.id}',
                              ),
                              icon: const Icon(Icons.picture_as_pdf_rounded),
                              label: const Text('PDF کامل کتاب'),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text('درس‌های کتاب', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
            const SizedBox(height: 10),
            if (book.lessons.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('هنوز درس فعالی برای این کتاب ثبت نشده است.', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              )
            else
              ...book.lessons.asMap().entries.map((entry) {
                final lesson = entry.value;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                      leading: Container(
                        width: 42,
                        height: 42,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: const Color(0xFFEEEAFD), borderRadius: BorderRadius.circular(13)),
                        child: Text('${entry.key + 1}', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF6C4EE3))),
                      ),
                      title: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: const Text('مشاهده گام به گام', style: TextStyle(color: Color(0xFF77758A), fontWeight: FontWeight.w700)),
                      trailing: const Icon(Icons.picture_as_pdf_rounded, color: Color(0xFF25A56A)),
                      onTap: () => _openPdf(
                        context,
                        title: 'گام به گام — ${lesson.title}',
                        url: lesson.stepPdfUrl,
                        documentId: 'step_${lesson.id}',
                        showInterstitial: true,
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class _AdiveryBannerCarousel extends StatefulWidget {
  const _AdiveryBannerCarousel({
    required this.enabled,
    required this.interval,
    this.bottomSafeArea = false,
  });

  final bool enabled;
  final Duration interval;
  final bool bottomSafeArea;

  @override
  State<_AdiveryBannerCarousel> createState() => _AdiveryBannerCarouselState();
}

class _AdiveryBannerCarouselState extends State<_AdiveryBannerCarousel> {
  final PageController _controller = PageController();
  Timer? _timer;
  int _page = 0;

  bool get _canRequest =>
      widget.enabled &&
      kAdiveryAppId.trim().isNotEmpty &&
      kAdiveryBannerPlacementId.trim().isNotEmpty;

  @override
  void initState() {
    super.initState();
    _syncTimer();
  }

  @override
  void didUpdateWidget(covariant _AdiveryBannerCarousel oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.enabled != widget.enabled || oldWidget.interval != widget.interval) _syncTimer();
  }

  void _syncTimer() {
    _timer?.cancel();
    if (!_canRequest) return;
    _timer = Timer.periodic(widget.interval, (_) {
      if (!mounted || !_controller.hasClients) return;
      final next = _page == 0 ? 1 : 0;
      _controller.animateToPage(
        next,
        duration: const Duration(milliseconds: 420),
        curve: Curves.easeInOutCubic,
      );
    });
  }

  @override
  void dispose() {
    _timer?.cancel();
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (!_canRequest) return const SizedBox.shrink();
    final content = SizedBox(
      height: 100,
      width: double.infinity,
      child: Stack(
        alignment: Alignment.center,
        children: [
          PageView.builder(
            controller: _controller,
            itemCount: 2,
            onPageChanged: (value) {
              if (!mounted || value == _page) return;
              setState(() => _page = value);
            },
            itemBuilder: (context, index) => _AdiveryLargeBannerPage(slot: index),
          ),
          Positioned(
            bottom: 5,
            child: IgnorePointer(
              child: DecoratedBox(
                decoration: BoxDecoration(
                  color: const Color(0x52000000),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 4),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: List.generate(2, (index) {
                      final active = index == _page;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 180),
                        margin: const EdgeInsets.symmetric(horizontal: 2),
                        width: active ? 8 : 6,
                        height: active ? 8 : 6,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          color: active ? Colors.white : const Color(0x8CFFFFFF),
                        ),
                      );
                    }),
                  ),
                ),
              ),
            ),
          ),
        ],
      ),
    );
    if (!widget.bottomSafeArea) return content;
    return SafeArea(
      top: false,
      child: ColoredBox(
        color: Colors.white,
        child: Padding(
          padding: const EdgeInsets.symmetric(vertical: 4),
          child: content,
        ),
      ),
    );
  }
}

class _AdiveryLargeBannerPage extends StatefulWidget {
  const _AdiveryLargeBannerPage({required this.slot});
  final int slot;

  @override
  State<_AdiveryLargeBannerPage> createState() => _AdiveryLargeBannerPageState();
}

class _AdiveryLargeBannerPageState extends State<_AdiveryLargeBannerPage> {
  bool _loaded = false;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: 320,
        height: 100,
        child: Stack(
          alignment: Alignment.center,
          children: [
            if (!_loaded)
              const SizedBox(
                width: 24,
                height: 24,
                child: CircularProgressIndicator(strokeWidth: 2.5),
              ),
            KeyedSubtree(
              key: ValueKey('adivery-large-banner-${widget.slot}'),
              child: BannerAd(
                kAdiveryBannerPlacementId,
                BannerAdSize.LARGE_BANNER,
                onAdLoaded: (_) {
                  if (mounted && !_loaded) setState(() => _loaded = true);
                },
                onError: (_, __) {
                  if (mounted && _loaded) setState(() => _loaded = false);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class PdfCache {
  static final Map<String, Future<File>> _inFlight = <String, Future<File>>{};
  static final Map<String, double> _activeProgress = <String, double>{};
  static final Map<String, List<void Function(double)>> _progressListeners =
      <String, List<void Function(double)>>{};

  static String _safeName(String documentId) {
    final safe = documentId.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    return safe.isEmpty ? 'document' : safe;
  }

  static Future<Directory> _cacheDirectory() async {
    final dir = await getApplicationSupportDirectory();
    final folder = Directory('${dir.path}/gambegam_pdf_cache');
    if (!await folder.exists()) await folder.create(recursive: true);
    return folder;
  }

  static Future<File> fileFor(String documentId) async {
    final folder = await _cacheDirectory();
    return File('${folder.path}/${_safeName(documentId)}.pdf');
  }

  static void _emitProgress(String key, double value) {
    final normalized = value.clamp(0.0, 1.0).toDouble();
    _activeProgress[key] = normalized;
    final listeners = List<void Function(double)>.from(
      _progressListeners[key] ?? const <void Function(double)>[],
    );
    for (final listener in listeners) {
      try {
        listener(normalized);
      } catch (_) {
        // A disposed screen must never interrupt a background download.
      }
    }
  }

  static void _cleanupFlight(String key) {
    _inFlight.remove(key);
    _activeProgress.remove(key);
    _progressListeners.remove(key);
  }

  static Future<bool> _looksLikePdf(File file) async {
    if (!await file.exists() || await file.length() < 1024) return false;
    RandomAccessFile? handle;
    try {
      handle = await file.open(mode: FileMode.read);
      final header = await handle.read(5);
      return header.length == 5 && ascii.decode(header, allowInvalid: true) == '%PDF-';
    } catch (_) {
      return false;
    } finally {
      if (handle != null) await handle.close();
    }
  }

  static Future<Map<String, dynamic>> _readResumeMeta(File file) async {
    if (!await file.exists()) return const <String, dynamic>{};
    try {
      final decoded = jsonDecode(await file.readAsString());
      return decoded is Map ? Map<String, dynamic>.from(decoded) : const <String, dynamic>{};
    } catch (_) {
      return const <String, dynamic>{};
    }
  }

  static Future<void> _writeResumeMeta(
    File file, {
    required String sourceUrl,
    String? etag,
    String? lastModified,
    int? totalBytes,
  }) async {
    await file.writeAsString(
      jsonEncode({
        'sourceUrl': sourceUrl,
        if (etag != null && etag.isNotEmpty) 'etag': etag,
        if (lastModified != null && lastModified.isNotEmpty) 'lastModified': lastModified,
        if (totalBytes != null && totalBytes > 0) 'totalBytes': totalBytes,
      }),
      flush: true,
    );
  }

  static ({int start, int end, int? total})? _parseContentRange(String? value) {
    if (value == null) return null;
    final match = RegExp(r'^bytes\s+(\d+)-(\d+)/(\d+|\*)$', caseSensitive: false).firstMatch(value.trim());
    if (match == null) return null;
    return (
      start: int.parse(match.group(1)!),
      end: int.parse(match.group(2)!),
      total: match.group(3) == '*' ? null : int.parse(match.group(3)!),
    );
  }

  static int? _parseUnsatisfiedTotal(String? value) {
    if (value == null) return null;
    final match = RegExp(r'^bytes\s+\*/(\d+)$', caseSensitive: false).firstMatch(value.trim());
    return match == null ? null : int.tryParse(match.group(1)!);
  }

  static Future<File> _promotePart(File part, File target, File meta) async {
    if (!await _looksLikePdf(part)) {
      throw const ContentException('فایل PDF دریافت‌شده معتبر نیست.');
    }
    if (await target.exists()) await target.delete();
    await part.rename(target.path);
    if (await meta.exists()) await meta.delete();
    return target;
  }

  static Future<File> ensure({
    required String documentId,
    required String sourceUrl,
    required void Function(double progress) onProgress,
  }) async {
    final key = _safeName(documentId);
    _progressListeners.putIfAbsent(key, () => <void Function(double)>[]).add(onProgress);

    final running = _inFlight[key];
    if (running != null) {
      final current = _activeProgress[key];
      if (current != null) onProgress(current);
      return running;
    }

    final future = _ensureInternal(
      key: key,
      documentId: documentId,
      sourceUrl: sourceUrl,
    );
    _inFlight[key] = future;
    unawaited(
      future.then<void>(
        (_) => _cleanupFlight(key),
        onError: (Object _, StackTrace __) => _cleanupFlight(key),
      ),
    );
    return future;
  }

  static Future<File> _ensureInternal({
    required String key,
    required String documentId,
    required String sourceUrl,
  }) async {
    final target = await fileFor(documentId);
    if (await _looksLikePdf(target)) {
      final stalePart = File('${target.path}.part');
      final staleMeta = File('${target.path}.part.meta');
      if (await stalePart.exists()) await stalePart.delete();
      if (await staleMeta.exists()) await staleMeta.delete();
      _emitProgress(key, 1);
      return target;
    }
    if (await target.exists()) await target.delete();

    final part = File('${target.path}.part');
    final meta = File('${target.path}.part.meta');
    var resumeMeta = await _readResumeMeta(meta);
    if (resumeMeta['sourceUrl']?.toString() != sourceUrl) {
      if (await part.exists()) await part.delete();
      if (await meta.exists()) await meta.delete();
      resumeMeta = const <String, dynamic>{};
    }

    final initialExisting = await part.exists() ? await part.length() : 0;
    final knownTotal = (resumeMeta['totalBytes'] as num?)?.toInt();
    if (initialExisting > 0 && knownTotal != null && knownTotal > 0) {
      _emitProgress(key, initialExisting / knownTotal);
      if (initialExisting == knownTotal && await _looksLikePdf(part)) {
        _emitProgress(key, 1);
        return _promotePart(part, target, meta);
      }
    }

    final client = http.Client();
    try {
      for (var attempt = 0; attempt < 2; attempt++) {
        var existing = await part.exists() ? await part.length() : 0;
        final request = http.Request('GET', Uri.parse(sourceUrl));
        request.headers['Accept-Encoding'] = 'identity';
        if (existing > 0) {
          request.headers['Range'] = 'bytes=$existing-';
          final savedEtag = resumeMeta['etag']?.toString() ?? '';
          final savedLastModified = resumeMeta['lastModified']?.toString() ?? '';
          final validator = savedEtag.isNotEmpty ? savedEtag : savedLastModified;
          if (validator.isNotEmpty) request.headers['If-Range'] = validator;
        }

        final response = await client.send(request).timeout(const Duration(seconds: 25));

        if (response.statusCode == 416 && existing > 0) {
          final total = _parseUnsatisfiedTotal(response.headers['content-range']);
          await response.stream.drain();
          if (total != null && total == existing && await _looksLikePdf(part)) {
            _emitProgress(key, 1);
            return _promotePart(part, target, meta);
          }
          if (await part.exists()) await part.delete();
          if (await meta.exists()) await meta.delete();
          resumeMeta = const <String, dynamic>{};
          continue;
        }

        if (response.statusCode != 200 && response.statusCode != 206) {
          await response.stream.drain();
          throw const ContentException('دانلود PDF ناموفق بود.');
        }

        var append = existing > 0 && response.statusCode == 206;
        final contentRange = _parseContentRange(response.headers['content-range']);
        if (append && contentRange != null && contentRange.start != existing) {
          await response.stream.drain();
          if (await part.exists()) await part.delete();
          if (await meta.exists()) await meta.delete();
          resumeMeta = const <String, dynamic>{};
          continue;
        }

        // A 200 response to a Range request means the server ignored Range (or
        // If-Range detected a changed file). Restart safely instead of appending.
        if (!append) existing = 0;

        final totalBytes = contentRange?.total ??
            (response.contentLength == null ? null : existing + response.contentLength!);
        await _writeResumeMeta(
          meta,
          sourceUrl: sourceUrl,
          etag: response.headers['etag'],
          lastModified: response.headers['last-modified'],
          totalBytes: totalBytes,
        );

        if (totalBytes != null && totalBytes > 0 && existing > 0) {
          _emitProgress(key, existing / totalBytes);
        } else if (existing == 0) {
          _emitProgress(key, 0);
        }

        final sink = part.openWrite(mode: append ? FileMode.append : FileMode.write);
        var received = existing;
        try {
          await for (final chunk in response.stream.timeout(const Duration(seconds: 30))) {
            sink.add(chunk);
            received += chunk.length;
            if (totalBytes != null && totalBytes > 0) {
              _emitProgress(key, received / totalBytes);
            }
          }
        } finally {
          await sink.close();
        }

        final actualLength = await part.length();
        if (totalBytes != null && totalBytes > 0 && actualLength < totalBytes) {
          throw const ContentException('دانلود کامل نشد. با ورود دوباره از همین نقطه ادامه پیدا می‌کند.');
        }
        if (actualLength < 1024 || !await _looksLikePdf(part)) {
          throw const ContentException('فایل PDF دریافت‌شده معتبر نیست.');
        }

        _emitProgress(key, 1);
        return _promotePart(part, target, meta);
      }
      throw const ContentException('امکان ادامه دانلود فراهم نشد. دوباره تلاش کنید.');
    } on TimeoutException {
      throw const ContentException('دانلود متوقف شد. با ورود دوباره از همان نقطه ادامه پیدا می‌کند.');
    } on SocketException {
      throw const ContentException('اینترنت قطع شد. با ورود دوباره دانلود از همان نقطه ادامه پیدا می‌کند.');
    } finally {
      client.close();
    }
  }
}

class PdfReaderScreen extends StatefulWidget {
  const PdfReaderScreen({
    super.key,
    required this.title,
    required this.pdfUrl,
    required this.documentId,
    required this.adsEnabled,
  });
  final String title;
  final String pdfUrl;
  final String documentId;
  final bool adsEnabled;

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> {
  File? _file;
  String _error = '';
  double _progress = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  Future<void> _prepare() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = '';
        _progress = 0;
      });
    }
    try {
      final file = await PdfCache.ensure(
        documentId: widget.documentId,
        sourceUrl: widget.pdfUrl,
        onProgress: (value) {
          if (mounted) setState(() => _progress = value);
        },
      );
      if (!mounted) return;
      setState(() {
        _file = file;
        _loading = false;
        _progress = 1;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      bottomNavigationBar: _AdiveryBannerCarousel(
        enabled: true,
        interval: const Duration(seconds: 40),
        bottomSafeArea: true,
      ),
      body: SafeArea(
        child: _loading
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 14),
                      Text(
                        _progress > 0 ? 'در حال دریافت PDF • ${(_progress * 100).round()}٪' : 'در حال آماده‌سازی PDF…',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
              )
            : _file == null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(22),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.error_outline_rounded, size: 46, color: Color(0xFF6C4EE3)),
                              const SizedBox(height: 12),
                              Text(_error.isEmpty ? 'PDF باز نشد.' : _error, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.7)),
                              const SizedBox(height: 14),
                              FilledButton.icon(onPressed: _prepare, icon: const Icon(Icons.refresh_rounded), label: const Text('تلاش دوباره')),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                : PDFView(
                    filePath: _file!.path,
                    enableSwipe: true,
                    swipeHorizontal: false,
                    // AndroidPdfViewer's pageFling=true intentionally behaves
                    // like a ViewPager and limits a fling to one page. Keep
                    // both fling and snap disabled for true free scrolling.
                    autoSpacing: false,
                    pageFling: false,
                    pageSnap: false,
                    fitEachPage: false,
                    fitPolicy: FitPolicy.WIDTH,
                  ),
      ),
    );
  }
}
