#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
TEMP_DIR="$(mktemp -d)"
trap 'rm -rf "$TEMP_DIR"' EXIT

flutter create --platforms=android --org ir.miplus --project-name gambegam_wrapper --no-pub "$TEMP_DIR/wrapper" >/dev/null
mkdir -p "$ROOT/android/gradle/wrapper"
cp "$TEMP_DIR/wrapper/android/gradle/wrapper/gradle-wrapper.jar" "$ROOT/android/gradle/wrapper/gradle-wrapper.jar"
cp "$TEMP_DIR/wrapper/android/gradlew" "$ROOT/android/gradlew"
cp "$TEMP_DIR/wrapper/android/gradlew.bat" "$ROOT/android/gradlew.bat"
chmod +x "$ROOT/android/gradlew"
cat > "$ROOT/android/gradle/wrapper/gradle-wrapper.properties" <<'PROPS'
distributionBase=GRADLE_USER_HOME
distributionPath=wrapper/dists
distributionUrl=https\://services.gradle.org/distributions/gradle-8.7-bin.zip
networkTimeout=10000
validateDistributionUrl=true
zipStoreBase=GRADLE_USER_HOME
zipStorePath=wrapper/dists
PROPS
cp "$ROOT/build_support/gamino-release-key.jks" "$ROOT/android/app/gamino-release-key.jks"
cp "$ROOT/build_support/key.properties" "$ROOT/android/key.properties"
