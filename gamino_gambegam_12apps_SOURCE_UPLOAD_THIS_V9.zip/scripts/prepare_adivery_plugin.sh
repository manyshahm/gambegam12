#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DEST="$ROOT/third_party/adivery"
REPO="https://github.com/adivery/adivery-flutter-plugin.git"
TAG="4.9.0"
EXPECTED_PREFIX="96cdd72"

rm -rf "$DEST"
mkdir -p "$(dirname "$DEST")"

echo "Fetching official Adivery Flutter plugin $TAG ..."
git clone --quiet --depth 1 --branch "$TAG" "$REPO" "$DEST"

actual="$(git -C "$DEST" rev-parse HEAD)"
case "$actual" in
  ${EXPECTED_PREFIX}*) ;;
  *)
    echo "ERROR: Adivery tag $TAG resolved to unexpected commit: $actual" >&2
    exit 31
    ;;
esac

python3 - "$DEST" <<'PY'
from pathlib import Path
import re, sys
root = Path(sys.argv[1])
pub = root / 'pubspec.yaml'
text = pub.read_text(encoding='utf-8')

if not re.search(r"(?m)^version:\s*4\.9\.0\s*$", text):
    raise SystemExit('ERROR: unexpected Adivery package version')

# Adivery 4.9.0 source is null-safe and used by its current Android 4.9.0 SDK,
# but its published Flutter pubspec still declares the pre-Dart-3 upper bound.
# Patch only that metadata bound locally so Flutter 3.29.3 / Dart 3.7 can solve it.
new, count = re.subn(
    r"(?m)^(\s*sdk:\s*['\"]?)>=2\.12\.0\s+<3\.0\.0(['\"]?\s*)$",
    r"\1>=2.12.0 <4.0.0\2",
    text,
    count=1,
)
if count != 1:
    raise SystemExit('ERROR: expected Adivery Dart SDK bound was not found')
pub.write_text(new, encoding='utf-8')

# The 4.9.0 Android SDK is on Maven Central. Remove the obsolete Bintray repo
# so a dead legacy repository can never block Gradle dependency resolution.
for gradle in (root / 'android' / 'build.gradle.kts', root / 'android' / 'build.gradle'):
    if gradle.exists():
        g = gradle.read_text(encoding='utf-8')
        g = re.sub(r"(?m)^\s*maven\s*\(\s*url\s*=\s*['\"]https://dl\.bintray\.com/adivery/maven['\"]\s*\)\s*$\n?", '', g)
        g = re.sub(r"(?m)^\s*maven\s*\{\s*url\s+['\"]https://dl\.bintray\.com/adivery/maven['\"]\s*\}\s*$\n?", '', g)
        gradle.write_text(g, encoding='utf-8')
PY

# Strip VCS metadata after verification; this becomes an ordinary path dependency.
rm -rf "$DEST/.git"

test -f "$DEST/lib/adivery.dart"
test -f "$DEST/lib/adivery_ads.dart"
grep -Eq '^version:[[:space:]]*4\.9\.0[[:space:]]*$' "$DEST/pubspec.yaml"
grep -Eq "sdk:[[:space:]]*['\"]?>=2\.12\.0[[:space:]]+<4\.0\.0" "$DEST/pubspec.yaml"
! grep -q '<3\.0\.0' "$DEST/pubspec.yaml"
grep -R -q 'com.adivery:sdk:4.9.0' "$DEST/android"
! grep -R -q 'dl.bintray.com/adivery/maven' "$DEST/android"

echo "Adivery 4.9.0 prepared for Dart 3 successfully."
