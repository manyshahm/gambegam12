#!/usr/bin/env python3
from __future__ import annotations

import sys
from pathlib import Path

try:
    from PIL import Image, ImageOps
except ImportError as exc:
    raise SystemExit("Pillow is required: python3 -m pip install pillow") from exc

if len(sys.argv) != 2:
    raise SystemExit("usage: apply_grade_icon.py <icon-file>")

src = Path(sys.argv[1]).resolve()
if not src.is_file():
    raise SystemExit(f"icon file not found: {src}")

root = Path(__file__).resolve().parents[1]
res = root / "android" / "app" / "src" / "main" / "res"

try:
    image = Image.open(src).convert("RGBA")
except Exception as exc:
    raise SystemExit(f"cannot decode icon {src}: {exc}") from exc

if image.width < 64 or image.height < 64:
    raise SystemExit(f"icon is too small: {image.width}x{image.height}")

# Preserve the full artwork without stretching. Center it on a transparent square.
side = max(image.width, image.height)
canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
contained = ImageOps.contain(image, (side, side), method=Image.Resampling.LANCZOS)
canvas.alpha_composite(contained, ((side - contained.width) // 2, (side - contained.height) // 2))

sizes = {
    "mipmap-mdpi": 48,
    "mipmap-hdpi": 72,
    "mipmap-xhdpi": 96,
    "mipmap-xxhdpi": 144,
    "mipmap-xxxhdpi": 192,
}
for folder, size in sizes.items():
    out_dir = res / folder
    out_dir.mkdir(parents=True, exist_ok=True)
    resized = canvas.resize((size, size), Image.Resampling.LANCZOS)
    for name in ("ic_launcher.png", "ic_launcher_round.png"):
        resized.save(out_dir / name, "PNG", optimize=True)

# Keep the source icon in assets too for easy inspection/debugging.
assets_icon = root / "assets" / "app_icon.png"
assets_icon.parent.mkdir(parents=True, exist_ok=True)
canvas.resize((512, 512), Image.Resampling.LANCZOS).save(assets_icon, "PNG", optimize=True)

print(f"Applied launcher icon: {src.name} ({image.width}x{image.height})")
