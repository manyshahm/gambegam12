# No custom shrinking rules are required. Release shrinking is disabled intentionally.
