#!/usr/bin/env bash
set -euo pipefail

grade="${1:?grade is required}"
package_base="${PACKAGE_BASE:-ir.miplus.gambegam}"

case "$grade" in
  1)  grade_word="اول" ;;
  2)  grade_word="دوم" ;;
  3)  grade_word="سوم" ;;
  4)  grade_word="چهارم" ;;
  5)  grade_word="پنجم" ;;
  6)  grade_word="ششم" ;;
  7)  grade_word="هفتم" ;;
  8)  grade_word="هشتم" ;;
  9)  grade_word="نهم" ;;
  10) grade_word="دهم" ;;
  11) grade_word="یازدهم" ;;
  12) grade_word="دوازدهم" ;;
  *) echo "grade must be 1..12" >&2; exit 2 ;;
esac

printf -v grade_padded '%02d' "$grade"
APP_LABEL="گام به گام پایه ${grade_word}"
APP_PACKAGE="${package_base}.grade${grade_padded}"
APP_SLUG="grade${grade_padded}"

printf 'APP_LABEL=%s\n' "$APP_LABEL"
printf 'APP_PACKAGE=%s\n' "$APP_PACKAGE"
printf 'APP_SLUG=%s\n' "$APP_SLUG"
printf 'TARGET_GRADE=%s\n' "$grade"
