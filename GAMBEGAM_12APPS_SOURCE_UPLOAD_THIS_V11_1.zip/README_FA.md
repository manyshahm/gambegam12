# گام‌به‌گام ۱۲ پایه — V11.1

## هویت پروژه
این پروژه «اپ گامینو» نیست. این Codebase مشترک Flutter برای ساخت ۱۲ اپ مستقل «گام‌به‌گام» از پایه اول تا دوازدهم است.
نسخه برنامه برای همه پایه‌ها همچنان `1.0.0+1` است.

## Package Nameها
- پایه ۱: `ir.miplus.gambegam01`
- پایه ۲: `ir.miplus.gambegam02`
- پایه ۳: `ir.miplus.gambegam03`
- پایه ۴: `ir.miplus.gambegam04`
- پایه ۵: `ir.miplus.gambegam05`
- پایه ۶: `ir.miplus.gambegam06`
- پایه ۷: `ir.miplus.gambegam07`
- پایه ۸: `ir.miplus.gambegam08`
- پایه ۹: `ir.miplus.gambegam09`
- پایه ۱۰: `ir.miplus.gambegam10`
- پایه ۱۱: `ir.miplus.gambegam11`
- پایه ۱۲: `ir.miplus.gambegam12`

## اتصال‌ها
- محتوای کتاب و درس: Backend محتوای فعلی پروژه روی `gaminoapp.ir`.
- آمار و Remote Control: `https://gaminoapp.ir/gambegaman/api`.
- پنل: `https://gaminoapp.ir/gambegaman/admin-panel/`.

## اسلایدر تبلیغات V11.1
اسلایدر صفحه اصلی دیگر محدود به دو اسلاید نیست. Backend برای هر پایه یک لیست مرتب از تبلیغات فعال می‌فرستد.
هر تبلیغ دارای این فیلدهای مدیریتی است:
- نوع: Adivery یا بنر عادی
- پایه‌های هدف
- مدت نمایش همان اسلاید، ۳ تا ۳۰۰ ثانیه
- جایگاه مرتب‌سازی
- فعال/غیرفعال
- شروع و پایان اختیاری
- سقف بازدید اختیاری
- آمار بازدید و کلیک

پیش‌فرض تبلیغ جدید: فعال، شروع از همان لحظه، بدون پایان و با بازدید نامحدود.
اگر سقف بازدید تعیین شود، Backend دقیقاً پس از رسیدن به سقف، تبلیغ را غیرفعال می‌کند. اپ نیز پاسخ همان رویداد را می‌خواند و تبلیغ سقف‌خورده را بدون منتظرماندن برای Heartbeat بعدی از چرخه جاری خارج می‌کند.

### بنر عادی
- تصویر از Backend بارگذاری می‌شود.
- لینک هدف برای هر بنر ثبت می‌شود.
- با لمس تصویر، لینک هدف با برنامه خارجی/مرورگر باز می‌شود.
- هنگام فعال‌شدن اسلاید، بازدید ثبت می‌شود و هنگام لمس، کلیک ثبت می‌شود.

### Adivery
- از Zone ID همان پایه که در `scripts/grade_config.sh` تعریف شده استفاده می‌شود.
- زمان ماندن این اسلاید نیز از Backend می‌آید.
- بازدید بعد از Load شدن بنر و فعال بودن اسلاید ثبت می‌شود.
- کلیک با callback `onAdClicked` پلاگین Adivery 4.9.0 ثبت می‌شود.

## Interstitial
کنترل Interstitial هنگام بازکردن درس مثل V10 مستقل باقی مانده است: فعال/غیرفعال، Adivery یا تصویر+لینک و پایه‌های هدف.

## موارد حفظ‌شده
- پایه‌های ۱۰ تا ۱۲: انتخاب رشته ریاضی / تجربی / انسانی
- Offline-first / Stale-While-Revalidate محتوا
- Splash حدود ۲.۵ ثانیه
- PDF Reader با اسکرول آزاد واقعی
- دانلود PDF با Resume واقعی
- Adivery 4.9.0 pinned
- بنر Adivery پایین PDF با رفتار قبلی و گردش ۴۰ ثانیه؛ این جایگاه فعلاً جزو مدیریت اسلایدر صفحه اصلی نیست.

## Build در GitHub
Workflow `build-12-grades.yml` همراه V11.1 بدون تغییر منطقی نسبت به V11 نگه داشته شده است. ZIP سورس را داخل Repository قرار دهید و Workflow را در `.github/workflows/build-12-grades.yml` بگذارید.
Marker داخلی `.gambegam12-source` حفظ شده است.


## اصلاح بسته‌بندی V11.1
V11.1 یک Hotfix بسته‌بندی است و منطق تبلیغات V11 را تغییر نمی‌دهد. ZIP سورس عمداً بدون پوشهٔ Wrapper ساخته شده تا `.gambegam12-source`، `pubspec.yaml`، `lib/main.dart`، `scripts/grade_config.sh` و `grade_icons` مستقیم در ریشه ZIP باشند و مرحله `Detect Flutter source ZIP` در GitHub Actions آن را معتبر تشخیص دهد.
