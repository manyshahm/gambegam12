import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_pdfview/flutter_pdfview.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

const String kApiBaseUrl = String.fromEnvironment(
  'GAMINO_API_URL',
  defaultValue: 'https://gaminoapp.ir/gamino/api',
);
const int kTargetGrade = int.fromEnvironment('TARGET_GRADE', defaultValue: 1);
const String kBuildAppName = String.fromEnvironment('APP_NAME', defaultValue: 'گام به گام');
const List<String> kSeniorTracks = ['ریاضی', 'تجربی', 'انسانی'];

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const GradeStepByStepApp());
}

class GradeStepByStepApp extends StatelessWidget {
  const GradeStepByStepApp({super.key});

  @override
  Widget build(BuildContext context) {
    final grade = kTargetGrade.clamp(1, 12).toInt();
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: kBuildAppName,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.light,
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF6C4EE3),
          primary: const Color(0xFF6C4EE3),
          secondary: const Color(0xFF25A56A),
          surface: const Color(0xFFF8F8FC),
        ),
        scaffoldBackgroundColor: const Color(0xFFF5F6FA),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          backgroundColor: Colors.white,
          foregroundColor: Color(0xFF25233A),
          elevation: 0,
          scrolledUnderElevation: 1,
          titleTextStyle: TextStyle(
            color: Color(0xFF25233A),
            fontSize: 19,
            fontWeight: FontWeight.w900,
          ),
        ),
        cardTheme: CardThemeData(
          color: Colors.white,
          elevation: 0,
          margin: EdgeInsets.zero,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(20),
            side: const BorderSide(color: Color(0xFFE8E8F0)),
          ),
        ),
        filledButtonTheme: FilledButtonThemeData(
          style: FilledButton.styleFrom(
            backgroundColor: const Color(0xFF25A56A),
            foregroundColor: Colors.white,
            minimumSize: const Size(44, 46),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
            textStyle: const TextStyle(fontWeight: FontWeight.w900),
          ),
        ),
      ),
      builder: (context, child) => Directionality(
        textDirection: TextDirection.rtl,
        child: child ?? const SizedBox.shrink(),
      ),
      home: StepByStepHome(grade: grade),
    );
  }
}

String gradeLabel(int grade) {
  const labels = <int, String>{
    1: 'اول',
    2: 'دوم',
    3: 'سوم',
    4: 'چهارم',
    5: 'پنجم',
    6: 'ششم',
    7: 'هفتم',
    8: 'هشتم',
    9: 'نهم',
    10: 'دهم',
    11: 'یازدهم',
    12: 'دوازدهم',
  };
  return labels[grade] ?? grade.toString();
}

String normalizeTrack(int grade, String track) {
  if (grade < 10) return '';
  return kSeniorTracks.contains(track) ? track : kSeniorTracks.first;
}

String gradePathText(int grade, String track) {
  final base = 'پایه ${gradeLabel(grade)}';
  final normalized = normalizeTrack(grade, track);
  return normalized.isEmpty ? base : '$base • $normalized';
}

class LearningLesson {
  const LearningLesson({
    required this.id,
    required this.title,
    required this.lessonNumber,
    required this.sortOrder,
    required this.updatedAt,
    required this.stepPdfUrl,
  });

  final String id;
  final String title;
  final int lessonNumber;
  final int sortOrder;
  final String updatedAt;
  final String stepPdfUrl;

  factory LearningLesson.fromJson(Map<String, dynamic> json) => LearningLesson(
        id: json['id']?.toString() ?? '',
        title: (json['title']?.toString() ?? '').trim().isNotEmpty ? json['title'].toString() : 'درس',
        lessonNumber: (json['lessonNumber'] as num?)?.toInt() ?? 0,
        sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
        updatedAt: json['updatedAt']?.toString() ?? '',
        stepPdfUrl: json['stepPdfUrl']?.toString() ?? '',
      );

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'lessonNumber': lessonNumber,
        'sortOrder': sortOrder,
        'updatedAt': updatedAt,
        'stepPdfUrl': stepPdfUrl,
      };
}

class LearningBook {
  const LearningBook({
    required this.id,
    required this.grade,
    required this.track,
    required this.title,
    required this.coverUrl,
    required this.pdfUrl,
    required this.sortOrder,
    required this.updatedAt,
    required this.lessons,
  });

  final String id;
  final int grade;
  final String track;
  final String title;
  final String coverUrl;
  final String pdfUrl;
  final int sortOrder;
  final String updatedAt;
  final List<LearningLesson> lessons;

  bool get hasPdf => pdfUrl.trim().isNotEmpty;

  factory LearningBook.fromJson(Map<String, dynamic> json) {
    final lessons = (json['lessons'] as List? ?? const [])
        .whereType<Map>()
        .map((item) => LearningLesson.fromJson(Map<String, dynamic>.from(item)))
        .where((item) => item.stepPdfUrl.trim().isNotEmpty)
        .toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return LearningBook(
      id: json['id']?.toString() ?? '',
      grade: (json['grade'] as num?)?.toInt() ?? kTargetGrade,
      track: json['track']?.toString() ?? '',
      title: (json['title']?.toString() ?? '').trim().isNotEmpty ? json['title'].toString() : 'کتاب',
      coverUrl: json['coverUrl']?.toString() ?? '',
      pdfUrl: json['pdfUrl']?.toString() ?? '',
      sortOrder: (json['sortOrder'] as num?)?.toInt() ?? 0,
      updatedAt: json['updatedAt']?.toString() ?? '',
      lessons: lessons,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'grade': grade,
        'track': track,
        'title': title,
        'coverUrl': coverUrl,
        'pdfUrl': pdfUrl,
        'sortOrder': sortOrder,
        'updatedAt': updatedAt,
        'lessons': lessons.map((e) => e.toJson()).toList(),
      };
}

class ContentApi {
  static Future<List<LearningBook>> loadBooks({required int grade, required String track}) async {
    final uri = Uri.parse('$kApiBaseUrl/index.php?action=guest.books');
    late http.Response response;
    try {
      response = await http
          .post(
            uri,
            headers: const {
              'Accept': 'application/json',
              'Content-Type': 'application/json; charset=utf-8',
            },
            body: jsonEncode({'grade': grade, 'track': normalizeTrack(grade, track)}),
          )
          .timeout(const Duration(seconds: 18));
    } on TimeoutException {
      throw const ContentException('پاسخ سرور طول کشید. اتصال اینترنت را بررسی کنید.');
    } on SocketException {
      throw const ContentException('اتصال اینترنت را بررسی کنید و دوباره تلاش کنید.');
    } catch (_) {
      throw const ContentException('اتصال به سرور انجام نشد.');
    }

    Map<String, dynamic> decoded;
    try {
      final raw = jsonDecode(response.body);
      if (raw is! Map) throw const FormatException();
      decoded = Map<String, dynamic>.from(raw);
    } catch (_) {
      throw const ContentException('پاسخ معتبر از سرور دریافت نشد.');
    }

    if (response.statusCode < 200 || response.statusCode >= 300 || decoded['ok'] != true) {
      throw ContentException(decoded['error']?.toString() ?? 'دریافت محتوا از سرور ناموفق بود.');
    }

    final data = decoded['data'];
    if (data is! Map) return const [];
    final rows = Map<String, dynamic>.from(data)['books'] as List? ?? const [];
    final books = rows
        .whereType<Map>()
        .map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item)))
        .toList()
      ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return books;
  }
}

class ContentException implements Exception {
  const ContentException(this.message);
  final String message;
  @override
  String toString() => message;
}

class LocalContentCache {
  static String _key(int grade, String track) => 'gambegam_books_v1_${grade}_${normalizeTrack(grade, track)}';

  static Future<void> save(int grade, String track, List<LearningBook> books) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_key(grade, track), jsonEncode(books.map((e) => e.toJson()).toList()));
  }

  static Future<List<LearningBook>> read(int grade, String track) async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_key(grade, track));
    if (raw == null || raw.isEmpty) return const [];
    try {
      final decoded = jsonDecode(raw);
      if (decoded is! List) return const [];
      final books = decoded
          .whereType<Map>()
          .map((item) => LearningBook.fromJson(Map<String, dynamic>.from(item)))
          .toList()
        ..sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
      return books;
    } catch (_) {
      return const [];
    }
  }

  static Future<String> readTrack(int grade) async {
    if (grade < 10) return '';
    final prefs = await SharedPreferences.getInstance();
    return normalizeTrack(grade, prefs.getString('gambegam_track_v1_$grade') ?? '');
  }

  static Future<void> saveTrack(int grade, String track) async {
    if (grade < 10) return;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('gambegam_track_v1_$grade', normalizeTrack(grade, track));
  }
}

class StepByStepHome extends StatefulWidget {
  const StepByStepHome({super.key, required this.grade});
  final int grade;

  @override
  State<StepByStepHome> createState() => _StepByStepHomeState();
}

class _StepByStepHomeState extends State<StepByStepHome> {
  List<LearningBook> _books = const [];
  String _track = '';
  bool _loading = true;
  String _error = '';
  bool _showingCached = false;

  @override
  void initState() {
    super.initState();
    _initialize();
  }

  Future<void> _initialize() async {
    _track = await LocalContentCache.readTrack(widget.grade);
    if (widget.grade < 10) _track = '';
    if (mounted) setState(() {});
    await _load();
  }

  Future<void> _load({bool silent = false}) async {
    if (!silent && mounted) {
      setState(() {
        _loading = true;
        _error = '';
      });
    }
    try {
      final books = await ContentApi.loadBooks(grade: widget.grade, track: _track);
      await LocalContentCache.save(widget.grade, _track, books);
      if (!mounted) return;
      setState(() {
        _books = books;
        _loading = false;
        _error = '';
        _showingCached = false;
      });
    } catch (error) {
      final cached = await LocalContentCache.read(widget.grade, _track);
      if (!mounted) return;
      setState(() {
        _books = cached;
        _loading = false;
        _error = error.toString();
        _showingCached = cached.isNotEmpty;
      });
    }
  }

  Future<void> _changeTrack(String track) async {
    final next = normalizeTrack(widget.grade, track);
    if (next == _track) return;
    setState(() {
      _track = next;
      _books = const [];
      _error = '';
      _loading = true;
    });
    await LocalContentCache.saveTrack(widget.grade, next);
    await _load();
  }

  @override
  Widget build(BuildContext context) {
    final gradeText = gradePathText(widget.grade, _track);
    return Scaffold(
      appBar: AppBar(
        automaticallyImplyLeading: false,
        title: Text('گام به گام پایه ${gradeLabel(widget.grade)}'),
      ),
      body: SafeArea(
        child: RefreshIndicator(
          onRefresh: () => _load(silent: true),
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
            children: [
              _HeaderCard(gradeText: gradeText),
              if (widget.grade >= 10) ...[
                const SizedBox(height: 14),
                _TrackSelector(selected: _track, onChanged: _changeTrack),
              ],
              if (_loading) ...[
                const SizedBox(height: 14),
                const LinearProgressIndicator(minHeight: 3),
              ],
              if (_showingCached) ...[
                const SizedBox(height: 12),
                const _InfoStrip(
                  icon: Icons.offline_bolt_rounded,
                  text: 'اتصال برقرار نشد؛ آخرین محتوای ذخیره‌شده نمایش داده می‌شود.',
                ),
              ],
              const SizedBox(height: 18),
              Text(
                'کتاب‌های $gradeText',
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w900, color: Color(0xFF25233A)),
              ),
              const SizedBox(height: 10),
              if (!_loading && _books.isEmpty)
                _EmptyState(error: _error, onRetry: _load)
              else
                ..._books.map((book) => Padding(
                      padding: const EdgeInsets.only(bottom: 12),
                      child: _BookTile(book: book),
                    )),
            ],
          ),
        ),
      ),
    );
  }
}

class _HeaderCard extends StatelessWidget {
  const _HeaderCard({required this.gradeText});
  final String gradeText;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: const LinearGradient(
          colors: [Color(0xFF6C4EE3), Color(0xFF846DF0)],
          begin: Alignment.topRight,
          end: Alignment.bottomLeft,
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 52,
            height: 52,
            decoration: BoxDecoration(color: Colors.white.withOpacity(.16), borderRadius: BorderRadius.circular(17)),
            child: const Icon(Icons.menu_book_rounded, color: Colors.white, size: 30),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('گام به گام', style: TextStyle(color: Colors.white, fontSize: 21, fontWeight: FontWeight.w900)),
                const SizedBox(height: 4),
                Text(gradeText, style: TextStyle(color: Colors.white.withOpacity(.88), fontWeight: FontWeight.w800)),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _TrackSelector extends StatelessWidget {
  const _TrackSelector({required this.selected, required this.onChanged});
  final String selected;
  final ValueChanged<String> onChanged;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('انتخاب رشته', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
            const SizedBox(height: 10),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: kSeniorTracks
                  .map(
                    (track) => ChoiceChip(
                      label: Text(track, style: const TextStyle(fontWeight: FontWeight.w900)),
                      selected: normalizeTrack(10, selected) == track,
                      onSelected: (_) => onChanged(track),
                    ),
                  )
                  .toList(),
            ),
          ],
        ),
      ),
    );
  }
}

class _InfoStrip extends StatelessWidget {
  const _InfoStrip({required this.icon, required this.text});
  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 11),
      decoration: BoxDecoration(color: const Color(0xFFFFF6DD), borderRadius: BorderRadius.circular(15)),
      child: Row(
        children: [
          Icon(icon, color: const Color(0xFFA36A00), size: 21),
          const SizedBox(width: 9),
          Expanded(child: Text(text, style: const TextStyle(fontWeight: FontWeight.w800, color: Color(0xFF6D4D0B)))),
        ],
      ),
    );
  }
}

class _EmptyState extends StatelessWidget {
  const _EmptyState({required this.error, required this.onRetry});
  final String error;
  final Future<void> Function({bool silent}) onRetry;

  @override
  Widget build(BuildContext context) {
    final message = error.trim().isEmpty
        ? 'هنوز محتوایی برای این پایه ثبت نشده است.'
        : error;
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(22),
        child: Column(
          children: [
            const Icon(Icons.cloud_off_rounded, size: 46, color: Color(0xFF6C4EE3)),
            const SizedBox(height: 12),
            Text(message, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.7)),
            const SizedBox(height: 14),
            FilledButton.icon(
              onPressed: () => onRetry(silent: false),
              icon: const Icon(Icons.refresh_rounded),
              label: const Text('تلاش دوباره'),
            ),
          ],
        ),
      ),
    );
  }
}

class _BookTile extends StatelessWidget {
  const _BookTile({required this.book});
  final LearningBook book;

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
        leading: _BookCover(url: book.coverUrl),
        title: Text(book.title, style: const TextStyle(fontWeight: FontWeight.w900)),
        subtitle: Padding(
          padding: const EdgeInsets.only(top: 4),
          child: Text(
            '${book.lessons.length} درس${book.hasPdf ? ' • PDF کامل' : ''}',
            style: const TextStyle(color: Color(0xFF77758A), fontWeight: FontWeight.w700),
          ),
        ),
        trailing: const Icon(Icons.chevron_left_rounded),
        onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => BookScreen(book: book))),
      ),
    );
  }
}

class _BookCover extends StatelessWidget {
  const _BookCover({required this.url, this.size = 56});
  final String url;
  final double size;

  @override
  Widget build(BuildContext context) {
    final placeholder = Container(
      width: size,
      height: size * 1.23,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(14),
        gradient: const LinearGradient(colors: [Color(0xFF6C4EE3), Color(0xFF9B8AF4)]),
      ),
      alignment: Alignment.center,
      child: Icon(Icons.menu_book_rounded, color: Colors.white, size: size * .43),
    );
    if (url.trim().isEmpty) return placeholder;
    return ClipRRect(
      borderRadius: BorderRadius.circular(14),
      child: Image.network(
        url,
        width: size,
        height: size * 1.23,
        fit: BoxFit.cover,
        errorBuilder: (_, __, ___) => placeholder,
      ),
    );
  }
}

class BookScreen extends StatelessWidget {
  const BookScreen({super.key, required this.book});
  final LearningBook book;

  void _openPdf(BuildContext context, {required String title, required String url, required String documentId}) {
    if (url.trim().isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('لینک PDF برای این مورد ثبت نشده است.')));
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(
        builder: (_) => PdfReaderScreen(title: title, pdfUrl: url, documentId: documentId),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(book.title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 16, 16, 28),
          children: [
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _BookCover(url: book.coverUrl, size: 84),
                    const SizedBox(width: 14),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(book.title, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
                          const SizedBox(height: 7),
                          Text(gradePathText(book.grade, book.track), style: const TextStyle(color: Color(0xFF77758A), fontWeight: FontWeight.w700)),
                          if (book.hasPdf) ...[
                            const SizedBox(height: 12),
                            FilledButton.icon(
                              onPressed: () => _openPdf(
                                context,
                                title: 'PDF کامل — ${book.title}',
                                url: book.pdfUrl,
                                documentId: 'book_${book.id}',
                              ),
                              icon: const Icon(Icons.picture_as_pdf_rounded),
                              label: const Text('PDF کامل کتاب'),
                            ),
                          ],
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 18),
            const Text('درس‌های کتاب', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 20)),
            const SizedBox(height: 10),
            if (book.lessons.isEmpty)
              const Card(
                child: Padding(
                  padding: EdgeInsets.all(20),
                  child: Text('هنوز درس فعالی برای این کتاب ثبت نشده است.', textAlign: TextAlign.center, style: TextStyle(fontWeight: FontWeight.w800)),
                ),
              )
            else
              ...book.lessons.asMap().entries.map((entry) {
                final lesson = entry.value;
                return Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: Card(
                    child: ListTile(
                      contentPadding: const EdgeInsets.symmetric(horizontal: 13, vertical: 7),
                      leading: Container(
                        width: 42,
                        height: 42,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(color: const Color(0xFFEEEAFD), borderRadius: BorderRadius.circular(13)),
                        child: Text('${entry.key + 1}', style: const TextStyle(fontWeight: FontWeight.w900, color: Color(0xFF6C4EE3))),
                      ),
                      title: Text(lesson.title, style: const TextStyle(fontWeight: FontWeight.w900)),
                      subtitle: const Text('مشاهده گام به گام', style: TextStyle(color: Color(0xFF77758A), fontWeight: FontWeight.w700)),
                      trailing: const Icon(Icons.picture_as_pdf_rounded, color: Color(0xFF25A56A)),
                      onTap: () => _openPdf(
                        context,
                        title: 'گام به گام — ${lesson.title}',
                        url: lesson.stepPdfUrl,
                        documentId: 'step_${lesson.id}',
                      ),
                    ),
                  ),
                );
              }),
          ],
        ),
      ),
    );
  }
}

class PdfCache {
  static String _safeName(String documentId) {
    final safe = documentId.replaceAll(RegExp(r'[^A-Za-z0-9._-]'), '_');
    return safe.isEmpty ? 'document' : safe;
  }

  static Future<File> fileFor(String documentId) async {
    final dir = await getApplicationSupportDirectory();
    final folder = Directory('${dir.path}/gambegam_pdf_cache');
    if (!await folder.exists()) await folder.create(recursive: true);
    return File('${folder.path}/${_safeName(documentId)}.pdf');
  }

  static Future<File> ensure({
    required String documentId,
    required String sourceUrl,
    required void Function(double progress) onProgress,
  }) async {
    final target = await fileFor(documentId);
    if (await target.exists() && await target.length() > 1024) return target;

    final client = http.Client();
    try {
      final request = http.Request('GET', Uri.parse(sourceUrl));
      final response = await client.send(request).timeout(const Duration(seconds: 25));
      if (response.statusCode < 200 || response.statusCode >= 300) {
        throw const ContentException('دانلود PDF ناموفق بود.');
      }
      final temp = File('${target.path}.part');
      if (await temp.exists()) await temp.delete();
      final sink = temp.openWrite();
      final total = response.contentLength ?? 0;
      var received = 0;
      try {
        await for (final chunk in response.stream) {
          sink.add(chunk);
          received += chunk.length;
          if (total > 0) onProgress((received / total).clamp(0, 1));
        }
      } finally {
        await sink.close();
      }
      if (await temp.length() < 1024) {
        await temp.delete();
        throw const ContentException('فایل PDF دریافت‌شده معتبر نیست.');
      }
      if (await target.exists()) await target.delete();
      await temp.rename(target.path);
      return target;
    } on TimeoutException {
      throw const ContentException('دانلود PDF طول کشید. دوباره تلاش کنید.');
    } on SocketException {
      throw const ContentException('برای دانلود PDF اتصال اینترنت را بررسی کنید.');
    } finally {
      client.close();
    }
  }
}

class PdfReaderScreen extends StatefulWidget {
  const PdfReaderScreen({super.key, required this.title, required this.pdfUrl, required this.documentId});
  final String title;
  final String pdfUrl;
  final String documentId;

  @override
  State<PdfReaderScreen> createState() => _PdfReaderScreenState();
}

class _PdfReaderScreenState extends State<PdfReaderScreen> {
  File? _file;
  String _error = '';
  double _progress = 0;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _prepare();
  }

  Future<void> _prepare() async {
    if (mounted) {
      setState(() {
        _loading = true;
        _error = '';
        _progress = 0;
      });
    }
    try {
      final file = await PdfCache.ensure(
        documentId: widget.documentId,
        sourceUrl: widget.pdfUrl,
        onProgress: (value) {
          if (mounted) setState(() => _progress = value);
        },
      );
      if (!mounted) return;
      setState(() {
        _file = file;
        _loading = false;
        _progress = 1;
      });
    } catch (error) {
      if (!mounted) return;
      setState(() {
        _loading = false;
        _error = error.toString();
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.title)),
      body: SafeArea(
        child: _loading
            ? Center(
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const CircularProgressIndicator(),
                      const SizedBox(height: 14),
                      Text(
                        _progress > 0 ? 'در حال دریافت PDF • ${(_progress * 100).round()}٪' : 'در حال آماده‌سازی PDF…',
                        style: const TextStyle(fontWeight: FontWeight.w900),
                      ),
                    ],
                  ),
                ),
              )
            : _file == null
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Card(
                        child: Padding(
                          padding: const EdgeInsets.all(22),
                          child: Column(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              const Icon(Icons.error_outline_rounded, size: 46, color: Color(0xFF6C4EE3)),
                              const SizedBox(height: 12),
                              Text(_error.isEmpty ? 'PDF باز نشد.' : _error, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w900, height: 1.7)),
                              const SizedBox(height: 14),
                              FilledButton.icon(onPressed: _prepare, icon: const Icon(Icons.refresh_rounded), label: const Text('تلاش دوباره')),
                            ],
                          ),
                        ),
                      ),
                    ),
                  )
                : PDFView(
                    filePath: _file!.path,
                    enableSwipe: true,
                    swipeHorizontal: false,
                    autoSpacing: true,
                    pageFling: true,
                  ),
      ),
    );
  }
}
